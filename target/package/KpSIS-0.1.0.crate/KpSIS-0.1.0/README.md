# KpSIS

Sustainable SIS (Strategic Intelligence Service) to promote "<b>Core Values of Honesty &amp; Care</b>": qualified teams and required infrastrucures to make the projects self-sustainable.
